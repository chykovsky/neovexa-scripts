test('node timers', () => {
  expect(typeof setTimeout).toBe('function');
});

