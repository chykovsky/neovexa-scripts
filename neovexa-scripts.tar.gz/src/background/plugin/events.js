import EventEmitter from '@/common/events';

export default new EventEmitter([
  'scriptEdit',
  'scriptChanged',
]);
