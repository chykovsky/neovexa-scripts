---
name: Feature request
about: Suggest an idea for this project
title: "[Feature] "
labels: enhancement
assignees: ''

---

**Motivation**
<!-- Is your feature request related to a problem? Please describe what the problem is. -->

**Proposed Solution**
<!-- A clear and concise description of what you want to happen. -->

**Use Cases**
<!-- If applicable, please describe how you would use this feature. -->
